package com.davidpadaria.padaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadariaApplication.class, args);
	}

}
